# AirData ETL
## Cole Smith

Please see `AirDataset.scala` Documentation strings for usage.

An implementation of the above class can be found at `AirDatasetTest.scala`. Note that
this implementation is tested on a local file set. The documentation for the `AirDataset` class specifies
how lazy datasets can be loaded from any file path, including HDFS.

### ETL

The ETL object for `AirDataset.scala` handles schema conversions.

### Utility

Some operations come from the `Utility.scala` class. As of writing, this only contains routines
used by the AirData loader (and written by me), but the intention is that these operations are not
unique to the AirDataset, and may be used throughout the project.

This includes scalers which will work for any dataset. 

### Disclaimer

The code provided here is subject to change. This is a draft version.
